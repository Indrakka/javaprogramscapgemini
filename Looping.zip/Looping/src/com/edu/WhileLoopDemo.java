package com.edu;

public class WhileLoopDemo {

	public static void main(String[] args) {
		 int i=10;//start
		 while(i>=1){   //condition
		     System.out.println(i); //1
		     i=i-1; //update
		 }
		// System.out.println(i); //1
		 
	}

}
