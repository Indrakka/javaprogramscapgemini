package com.edu;

public class BreakAndContinue {

	public static void main(String[] args) {
		
		for(int i=1;i<=10;i++) {
			
			if(i==5) {
				continue;
			}
			System.out.println(i); //1 to 49 51 to 100
		}
		System.out.println("outside loop");

	}

}
