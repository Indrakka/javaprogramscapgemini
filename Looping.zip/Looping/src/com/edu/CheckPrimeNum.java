//prime num is one which is divisible by one and itself
//prime num has only 2 factors, 1 and numitself
//ex: 2,3,5,7,11,13,
package com.edu;

import java.util.Scanner;

public class CheckPrimeNum {

	public static void main(String[] args) {
		int num;
		int c=0;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number");
		num = sc.nextInt();
		
		for(int i=1;i<=num;i++) {
			if(num%i == 0) {
				c++;
			}
		}
		System.out.println("c="+c);
		if(c==2) {
			System.out.println(num+" is prime number");
		}else {
			System.out.println(num+" is not a prime number");
		}

	}

}
