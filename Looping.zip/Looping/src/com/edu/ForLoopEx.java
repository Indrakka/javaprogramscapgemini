package com.edu;

public class ForLoopEx {

	public static void main(String[] args) {
		//For loop
		/*
		 * Syntax
		 * for(initialization;condition;updation){
		 initialization is done only one time
		 //condition will chk n+1 
		 //updation will have n times
		 
		// */
		
		for(int i=1;i<=10;i++){
			System.out.println(i);
		}
	//	System.out.println(i); //11
		
		
		
		int j=1;
		for(;j<=10;) {
			System.out.println(j);
			j=j+1;
		}
		
		
		
//		for(;;) {
//			System.out.println("Infinite for loop");
//		}
//		while(true) {
//			System.out.println("infinite while loop");
//		}
		
	}

}
