package com.edu.nestedloop;

public class NestedLoopMain {

	public static void main(String[] args) {
		for(int i=3;i>=1;i--) {  //rows
			for(int j=3;j>=1;j--) { //columns
				//System.out.println("i="+i+" and j="+j);
				System.out.print("* ");
			}
			System.out.println();
		}

	}	
}

/*
 * 3 3 3
 * 2 2 2
 * 1 1 1
 * 
 * 
 * 3 2 1
 * 3 2 1
 * 3 2 1
 */


