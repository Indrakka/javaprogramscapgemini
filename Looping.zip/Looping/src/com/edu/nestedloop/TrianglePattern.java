package com.edu.nestedloop;

public class TrianglePattern {

	public static void main(String[] args) {
		for(int i=3;i>=1;i--) {
			for(int j=i;j>=1;j--) {
				System.out.print("* ");
				//System.out.print(i+" ");
				//System.out.print(i+" ");
			}
			System.out.println();
		}

	}

}

