package com.edu;

public class Dowhileex {

	public static void main(String[] args) {
		int i=1;
		do { //post check
			System.out.println("hello");
		}while(i<1);
		
		while(i<1) { //pre check
			System.out.println("hello");
		}

	}

}
