//find the sum of below series
//1/1+1/2+1/3+1/4+1/5+1/6+1/7+1/8+1/9+/1/10

//1/1-1/2+1/3-1/4+1/5-1/6+1/7-1/8+1/9-1/10
package com.edu;

public class SumSeries {

	public static void main(String[] args) {
		int i=1;
		float sum=0;
		
		while(i<=10) {
			if(i%2==0) {
				sum = sum-(float)1/i;
			}
			else
			{
				sum = sum+(float)1/i;
			}
			i=i+1;
		}
		
		System.out.println(sum);
		
	
		
		
	}

}
