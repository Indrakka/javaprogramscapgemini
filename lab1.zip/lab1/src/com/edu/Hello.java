package com.edu;

public class Hello {
   public static void main(String args[]) {
	   System.out.println("Edubridge");
	   System.out.println("Mumbai");
   }
}
