package com.edu;

import java.util.Scanner;

//import java.lang.*;

public class InputUser {

	public static void main(String[] args) {
		
		int age; //age123, age_123,a1234age
		float salary;
		String name;
		char gen;
		
		//input data from user
		
		//step 1:
		//create an object of Scanner
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter name");
		//name = sc.next();  //single word
		name=sc.nextLine();//with the space
		
		System.out.println("Enter age");
		age = sc.nextInt();
		
		System.out.println("Enter salary");
		salary = sc.nextFloat();
		//nextByte(), nextShort(), nextFloat(), nextDouble()
		
		
		
		System.out.println("Enter gender ");
		gen = sc.next().charAt(0); //read a char
		
		System.out.println("User details");
		System.out.println("Name="+name);
		System.out.println("Age="+age);
		System.out.println("Salary="+salary);
		System.out.println("Gender="+gen);
		
	}

}
