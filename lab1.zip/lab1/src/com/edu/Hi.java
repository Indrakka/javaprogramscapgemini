package com.edu;

public class Hi {

	public static void main(String[] args) {
		System.out.println("hi"+6+8);
		System.out.println(6+8+"hi");
		System.out.println("hi"+(6+8));
		System.out.println((6+8)+"hi");
		
		//System.out.println("hi"+6*8);
	}

}
