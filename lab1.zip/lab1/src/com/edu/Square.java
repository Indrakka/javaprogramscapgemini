package com.edu;

public class Square {

	public static void main(String[] args) {
		double side=45.3;
		double area;
		
		area = side*side;
		System.out.println("The area of square of side = "+ side +" is "+area);

	}

}
