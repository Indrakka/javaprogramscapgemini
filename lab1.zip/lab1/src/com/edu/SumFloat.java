package com.edu;

public class SumFloat {

	public static void main(String[] args) {
		float f1 = 12.4f;
		float f2 = 34.2f;
		
		float s;
		s=f1+f2;
		
		System.out.println("The sum of "+f1+" and "+f2+" is "+s);
	}

}
