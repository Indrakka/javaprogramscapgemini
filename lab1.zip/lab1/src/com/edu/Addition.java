package com.edu;

public class Addition {

	public static void main(String[] args) {
		int i = 10; 
		int j = 20;
		
		int s;
		s=i+j;
		System.out.println("The sum of "+i+" and "+j+" is "+s);
		//System.out.println(s);

	}

}
